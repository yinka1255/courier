<?php
define( 'LINE', 0 );
define( 'AREA', 1 );
define( 'VISUAL', 2 );
