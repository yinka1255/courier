<?php

class WPML_TM_Jobs_Summary {

	const WEEKLY_REPORT      = 'weekly';
	const DAILY_REPORT       = 'daily';
	const DAILY_SCHEDULE     = '1 day';
	const WEEKLY_SCHEDULE    = '1 week';
	const JOBS_COMPLETED_KEY = 'completed';
	const JOBS_WAITING_KEY   = 'waiting';
}